/**
 * This service handles the AI processing of audio to generate art
 * using OpenAI's DALL-E model
 */

import OpenAI from 'openai';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true // Note: In production, API calls should be made from a backend
});

// Fallback images in case the API call fails
const FALLBACK_IMAGES = [
  'https://images.unsplash.com/photo-1541701494587-cb58502866ab?q=80&w=2070&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1507838153414-b4b713384a76?q=80&w=2070&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?q=80&w=1974&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2073&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1550684376-efcbd6e3f031?q=80&w=2070&auto=format&fit=crop'
];

// Analyze audio to determine its characteristics
const analyzeAudio = async (audioBlob: Blob): Promise<string> => {
  // In a real app, this would analyze the audio file's frequency, amplitude, etc.
  // For now, we'll extract some basic metadata to use in our prompt
  
  try {
    const duration = await getAudioDuration(audioBlob);
    const fileSize = audioBlob.size;
    const fileType = audioBlob.type;
    
    // Return a basic description based on the audio metadata
    return `Audio file (${fileType}) of ${duration.toFixed(1)} seconds length and ${(fileSize / 1024).toFixed(1)}KB size`;
  } catch (err) {
    console.error('Error analyzing audio:', err);
    return 'Audio file with unknown characteristics';
  }
};

// Process the prompt to determine art style
const enhancePrompt = (basePrompt: string, audioDescription: string): string => {
  // If user provided a prompt, use it as the base
  let finalPrompt = basePrompt.trim();
  
  if (!finalPrompt) {
    // Default prompt if none provided
    finalPrompt = "Create a visual representation of this audio";
  }
  
  // Add audio description to the prompt
  finalPrompt += `. Based on ${audioDescription}.`;
  
  // Add style guidance if not already specified
  if (!finalPrompt.toLowerCase().includes('style')) {
    finalPrompt += " Use a modern digital art style with vibrant colors.";
  }
  
  // Add quality instructions
  finalPrompt += " High quality, detailed artwork with good composition.";
  
  return finalPrompt;
};

/**
 * Generate art from audio using DALL-E
 */
export const generateArtFromAudio = async (audioBlob: Blob, prompt: string): Promise<string> => {
  try {
    // Analyze the audio to get a description
    const audioDescription = await analyzeAudio(audioBlob);
    
    // Enhance the prompt with audio description
    const enhancedPrompt = enhancePrompt(prompt, audioDescription);
    
    console.log('Generating art with prompt:', enhancedPrompt);
    
    // Call DALL-E API to generate image
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: enhancedPrompt,
      n: 1,
      size: "1024x1024",
      quality: "standard",
      style: "vivid"
    });
    
    // Return the generated image URL
    return response.data[0].url;
  } catch (err) {
    console.error('Error generating art with DALL-E:', err);
    
    // If API call fails, return a fallback image
    const randomIndex = Math.floor(Math.random() * FALLBACK_IMAGES.length);
    return FALLBACK_IMAGES[randomIndex];
  }
};

// Helper function to convert blob to base64
export const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      resolve(base64String.split(',')[1]); // Remove the data URL prefix
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

// Get audio duration in seconds
export const getAudioDuration = async (blob: Blob): Promise<number> => {
  return new Promise((resolve) => {
    const audio = new Audio();
    audio.src = URL.createObjectURL(blob);
    
    audio.addEventListener('loadedmetadata', () => {
      resolve(audio.duration);
      URL.revokeObjectURL(audio.src);
    });
    
    // Fallback in case loadedmetadata doesn't fire
    setTimeout(() => resolve(30), 1000); // Default to 30 seconds
  });
};