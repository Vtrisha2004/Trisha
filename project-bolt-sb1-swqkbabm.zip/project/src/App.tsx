import React, { useState, useEffect } from 'react';
import { AudioRecorder } from 'react-audio-voice-recorder';
import { useDropzone } from 'react-dropzone';
import { 
  Mic, Upload, Wand2, Loader2, Volume2, ImageIcon, 
  RefreshCw, Download, Info, X, Music, Sparkles
} from 'lucide-react';
import { generateArtFromAudio, getAudioDuration } from './services/aiService';

function App() {
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioName, setAudioName] = useState<string>('');
  const [audioDuration, setAudioDuration] = useState<number>(0);
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [prompt, setPrompt] = useState<string>('');
  const [showTips, setShowTips] = useState<boolean>(false);
  const [generationCount, setGenerationCount] = useState<number>(0);
  const [processingProgress, setProcessingProgress] = useState<number>(0);
  const [apiKeyMissing, setApiKeyMissing] = useState<boolean>(false);

  // Check if API key is set
  useEffect(() => {
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    if (!apiKey || apiKey === 'your_openai_api_key_here') {
      setApiKeyMissing(true);
    }
  }, []);

  // Process progress simulation
  useEffect(() => {
    if (isProcessing) {
      const interval = setInterval(() => {
        setProcessingProgress(prev => {
          if (prev >= 95) {
            clearInterval(interval);
            return prev;
          }
          return prev + 5;
        });
      }, 500); // Slower progress for DALL-E generation
      
      return () => clearInterval(interval);
    } else {
      setProcessingProgress(0);
    }
  }, [isProcessing]);

  const onRecordingComplete = async (blob: Blob) => {
    setAudioBlob(blob);
    const url = URL.createObjectURL(blob);
    setAudioUrl(url);
    setAudioName('Recorded Audio.mp3');
    setIsRecording(false);
    
    try {
      const duration = await getAudioDuration(blob);
      setAudioDuration(duration);
    } catch (err) {
      console.error('Failed to get audio duration:', err);
    }
  };

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'audio/*': ['.mp3', '.wav', '.m4a', '.aac', '.ogg']
    },
    maxFiles: 1,
    onDrop: async (acceptedFiles) => {
      const file = acceptedFiles[0];
      if (file) {
        setAudioBlob(file);
        const url = URL.createObjectURL(file);
        setAudioUrl(url);
        setAudioName(file.name);
        
        try {
          const duration = await getAudioDuration(file);
          setAudioDuration(duration);
        } catch (err) {
          console.error('Failed to get audio duration:', err);
        }
      }
    }
  });

  const handleGenerateArt = async () => {
    if (!audioBlob) {
      setError('Please record or upload an audio file first');
      return;
    }

    if (apiKeyMissing) {
      setError('OpenAI API key is missing. Please add your API key to the .env file.');
      return;
    }

    try {
      setIsProcessing(true);
      setError(null);
      
      // Generate art using DALL-E
      const imageUrl = await generateArtFromAudio(audioBlob, prompt);
      setGeneratedImage(imageUrl);
      setGenerationCount(prev => prev + 1);
    } catch (err) {
      setError('Failed to generate art. Please try again.');
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const resetAll = () => {
    setAudioBlob(null);
    setAudioUrl(null);
    setAudioName('');
    setAudioDuration(0);
    setGeneratedImage(null);
    setError(null);
    setPrompt('');
    
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }
  };

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-950 to-slate-900 text-white">
      <div className="container mx-auto px-4 py-8 md:py-12">
        <header className="text-center mb-10">
          <div className="flex items-center justify-center mb-3">
            <Sparkles className="text-amber-400 mr-2" size={28} />
            <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-amber-300 via-pink-300 to-violet-300">
              Soundscape
            </h1>
            <Sparkles className="text-amber-400 ml-2" size={28} />
          </div>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Transform your sounds, music, and voice into beautiful AI-generated artwork with DALL-E
          </p>
        </header>

        {apiKeyMissing && (
          <div className="max-w-5xl mx-auto mb-6 bg-amber-900/30 border border-amber-800 text-amber-200 p-4 rounded-lg flex items-start">
            <Info className="mr-2 mt-0.5 flex-shrink-0" size={18} />
            <div>
              <p className="font-medium">OpenAI API Key Required</p>
              <p className="text-sm mt-1">
                To use DALL-E for image generation, add your OpenAI API key to the .env file:
                <code className="block bg-black/30 p-2 rounded mt-2 text-amber-100">
                  VITE_OPENAI_API_KEY=your_openai_api_key_here
                </code>
              </p>
            </div>
          </div>
        )}

        <div className="max-w-5xl mx-auto bg-slate-900/80 backdrop-blur-lg rounded-2xl overflow-hidden shadow-[0_0_40px_rgba(124,58,237,0.15)]">
          <div className="border-b border-slate-700 p-4 md:p-6 flex justify-between items-center">
            <div className="flex items-center">
              <Music className="text-violet-400 mr-2" />
              <h2 className="text-xl font-medium">Audio to Art Converter</h2>
            </div>
            <button 
              onClick={() => setShowTips(!showTips)}
              className="text-slate-400 hover:text-white transition-colors"
              aria-label={showTips ? "Hide tips" : "Show tips"}
            >
              <Info size={20} />
            </button>
          </div>

          {showTips && (
            <div className="bg-indigo-900/30 p-4 relative">
              <button 
                onClick={() => setShowTips(false)}
                className="absolute right-2 top-2 text-slate-400 hover:text-white"
                aria-label="Close tips"
              >
                <X size={18} />
              </button>
              <h3 className="font-medium mb-2">Tips for best results:</h3>
              <ul className="text-sm text-slate-300 list-disc pl-5 space-y-1">
                <li>Use clear audio with minimal background noise</li>
                <li>For music, 10-30 seconds of audio works best</li>
                <li>Add descriptive prompts like "abstract watercolor" or "vibrant landscape"</li>
                <li>Try different sections of the same audio for varied results</li>
                <li>Be specific in your prompts for DALL-E to generate better images</li>
              </ul>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
            <div className="p-6 md:p-8 border-b lg:border-b-0 lg:border-r border-slate-700">
              <h2 className="text-xl font-semibold flex items-center mb-6">
                <Volume2 className="mr-2 text-violet-400" /> Audio Input
              </h2>
              
              {/* Audio Recording Section */}
              <div className="bg-slate-800/50 rounded-xl p-6 mb-6">
                <div className="mb-6 text-center">
                  <h3 className="font-medium mb-3 flex items-center justify-center">
                    <Mic className="mr-2 text-pink-400" /> Record Audio
                  </h3>
                  <div className="flex justify-center">
                    <AudioRecorder 
                      onRecordingComplete={onRecordingComplete}
                      onStartRecording={() => setIsRecording(true)}
                      audioTrackConstraints={{
                        noiseSuppression: true,
                        echoCancellation: true,
                      }}
                      downloadOnSavePress={false}
                      downloadFileExtension="mp3"
                      classes={{
                        AudioRecorderClass: "!bg-violet-600 hover:!bg-violet-500",
                        AudioRecorderStartSaveClass: "!bg-violet-600 hover:!bg-violet-500"
                      }}
                    />
                  </div>
                  {isRecording && (
                    <div className="flex items-center justify-center mt-3">
                      <span className="relative flex h-3 w-3 mr-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-pink-500"></span>
                      </span>
                      <p className="text-pink-300">Recording...</p>
                    </div>
                  )}
                </div>

                <div className="w-full border-t border-slate-700 my-4"></div>

                <div className="w-full">
                  <h3 className="font-medium mb-3 flex items-center justify-center">
                    <Upload className="mr-2 text-pink-400" /> Upload Audio
                  </h3>
                  <div 
                    {...getRootProps()} 
                    className="border-2 border-dashed border-slate-600 rounded-xl p-6 text-center cursor-pointer hover:bg-slate-800/80 transition-colors"
                  >
                    <input {...getInputProps()} />
                    <p>Drag & drop an audio file here, or click to select</p>
                    <p className="text-xs text-slate-400 mt-2">Supports MP3, WAV, M4A, AAC, OGG</p>
                  </div>
                </div>
              </div>

              {/* Audio Preview */}
              {audioUrl && (
                <div className="bg-slate-800/50 rounded-xl p-6 mb-6">
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="font-medium">Audio Preview</h3>
                    {audioDuration > 0 && (
                      <span className="text-sm text-slate-400">{formatDuration(audioDuration)}</span>
                    )}
                  </div>
                  <div className="bg-slate-900 rounded-lg p-3 mb-3">
                    <p className="text-sm text-slate-300 truncate" title={audioName}>
                      {audioName || "Audio file"}
                    </p>
                    <audio controls className="w-full mt-2" src={audioUrl}>
                      Your browser does not support the audio element.
                    </audio>
                  </div>
                  <button 
                    onClick={resetAll}
                    className="text-sm text-pink-400 hover:text-pink-300 transition-colors flex items-center"
                  >
                    <RefreshCw size={14} className="mr-1" /> Clear and start over
                  </button>
                </div>
              )}

              {/* Prompt Input */}
              <div className="bg-slate-800/50 rounded-xl p-6 mb-6">
                <h3 className="font-medium mb-3">DALL-E Prompt</h3>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe what you want DALL-E to generate based on your audio... (e.g., 'Create a surreal landscape that represents the emotions in this music', 'Generate a portrait that captures the mood of this voice recording')"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white placeholder-slate-500 focus:border-violet-500 focus:ring focus:ring-violet-500/20 focus:outline-none"
                  rows={4}
                />
                <p className="text-xs text-slate-400 mt-2">
                  Your prompt will be enhanced with audio characteristics for better results
                </p>
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerateArt}
                disabled={!audioBlob || isProcessing}
                className={`w-full py-4 rounded-xl font-medium flex items-center justify-center transition-all ${
                  !audioBlob || isProcessing
                    ? 'bg-slate-700 cursor-not-allowed'
                    : 'bg-gradient-to-r from-violet-600 to-pink-600 hover:from-violet-500 hover:to-pink-500 shadow-lg hover:shadow-violet-500/20'
                }`}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="animate-spin mr-2" /> 
                    Generating with DALL-E... {processingProgress}%
                  </>
                ) : (
                  <>
                    <Wand2 className="mr-2" /> Generate with DALL-E
                  </>
                )}
              </button>

              {error && (
                <div className="mt-4 bg-red-900/30 border border-red-800 text-red-200 p-4 rounded-lg flex items-start">
                  <X className="mr-2 mt-0.5 flex-shrink-0" size={18} />
                  <p>{error}</p>
                </div>
              )}
            </div>

            {/* Result Section */}
            <div className="p-6 md:p-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold flex items-center">
                  <ImageIcon className="mr-2 text-violet-400" /> DALL-E Generated Art
                </h2>
                {generationCount > 0 && (
                  <span className="text-sm bg-violet-900/50 text-violet-300 px-2 py-1 rounded-full">
                    Generation #{generationCount}
                  </span>
                )}
              </div>
              
              <div className="bg-slate-800/50 rounded-xl p-4 h-[450px] flex items-center justify-center overflow-hidden">
                {generatedImage ? (
                  <div className="relative w-full h-full">
                    <img 
                      src={generatedImage} 
                      alt="DALL-E generated art from audio" 
                      className="w-full h-full object-contain rounded-lg"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent flex items-end justify-center p-4">
                      <a 
                        href={generatedImage} 
                        download="soundscape-dalle-art.jpg"
                        className="bg-slate-800/90 backdrop-blur-sm hover:bg-slate-700 text-white py-2 px-4 rounded-lg flex items-center transition-colors"
                      >
                        <Download size={18} className="mr-2" /> Download Image
                      </a>
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-slate-400">
                    <div className="relative w-32 h-32 mx-auto mb-4">
                      <div className="absolute inset-0 bg-gradient-to-r from-violet-600/20 to-pink-600/20 rounded-full animate-pulse"></div>
                      <div className="absolute inset-4 bg-slate-800 rounded-full flex items-center justify-center">
                        <ImageIcon size={48} className="text-slate-600" />
                      </div>
                    </div>
                    <p className="text-lg mb-2">Your DALL-E artwork will appear here</p>
                    <p className="text-sm max-w-xs mx-auto">
                      Record or upload audio and click "Generate with DALL-E" to transform your sounds into AI art
                    </p>
                  </div>
                )}
              </div>

              {generatedImage && (
                <div className="mt-6 bg-slate-800/50 rounded-xl p-6">
                  <h3 className="font-medium mb-3">About This DALL-E Generation</h3>
                  <div className="space-y-3 text-sm text-slate-300">
                    <p>
                      This artwork was generated by OpenAI's DALL-E model based on your audio characteristics and prompt. 
                      The AI analyzed patterns in your audio and combined them with your textual guidance to create this unique visual representation.
                    </p>
                    <p>
                      Try different audio clips or adjust your prompt to see how DALL-E interprets your input differently!
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <footer className="mt-12 text-center text-slate-400 text-sm">
          <p>Soundscape: Audio to Art AI Converter &copy; {new Date().getFullYear()}</p>
          <p className="mt-1">Powered by React and OpenAI's DALL-E</p>
        </footer>
      </div>
    </div>
  );
}

export default App;